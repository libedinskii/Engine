public class Main {
    public static void main(String[] args) {
        // Пример композиции
        Car car = new Car();
        car.startCar();

        // Пример агрегации
        Bicycle bicycle = new Bicycle();
        bicycle.ride();
    }
}
