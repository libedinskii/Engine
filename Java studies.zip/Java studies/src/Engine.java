class Engine {
    public void start() {
        System.out.println("Двигатель запущен");
    }
}
