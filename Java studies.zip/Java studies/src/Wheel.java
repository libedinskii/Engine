class Wheel {
    public void rotate() {
        System.out.println("Колесо вращается");
    }
}
